package com.junitdemo2;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

//business logic where we can add customers
public class CustomerManager {
	
	//java collection or hashmap that stores the customer data
	//in this demo,we are going to use hashmap
	//as temporary database
	private Map<String,Customer> customerList = new HashMap<String,Customer>();
	private String organizationName = "Airtel";
	
	//adding customer data to hashmap
	public Customer addCustomer(String id, String firstName, String lastName, String phoneNumber) {
		Customer customer = new Customer();
		customer.setCustomerId(id);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setPhoneNumber(phoneNumber);
		boolean exists = checkIfCustomerAlreadyExists(customer);
		//if customerId does not exist in the hashmap
		if(!exists) {
			customerList.put(id, customer);
		}
		return customer;
	}
	
	private boolean checkIfCustomerAlreadyExists(Customer customer) {
		if(customerList.containsKey(customer.getCustomerId()))
			return true;
		return false;
	}
	
	public String getOrganization() {
		return organizationName;
	}
	
	public Collection<Customer> getAllCustomers() {
		return customerList.values();
	}
	

}
