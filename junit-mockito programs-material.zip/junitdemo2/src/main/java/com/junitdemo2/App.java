package com.junitdemo2;


public class App 
{
    public static void main( String[] args )
    {
        CustomerManager manager = new CustomerManager();
        manager.addCustomer("c100", "kiran", "kumar", "7388585");
        manager.addCustomer("c101", "ramesh", "kumar", "465464");
        manager.addCustomer("c103", "sekar", "babu", "48585758");
        manager.addCustomer("c104", "rajesh", "kumar", "748585");
        manager.addCustomer("c105", "Abdul", "Rehman", "465757565");
        
        int count = manager.getAllCustomers().size();
        
        System.out.println("count "+count);
    }
}
