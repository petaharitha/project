package com.junitdemo2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Collection;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CustomerManagerTest {
	
	CustomerManager manager = null;
	
	//when CustomerManagerTest is executed, first  initializeCommonData
	//gets executed before exeucting any of the @Test method
	@BeforeAll
	public static void initializeCommonData() {
		
	}
	
	//this gets executed before executin any of the @Test method
	@BeforeEach
	public void init() {
		manager = new CustomerManager();
	}
	
	
	//this test method will be used test addCustomer method in CustomerManager class
	@Test
	public void addCustomerTest() {
		
		//define input to be passed to addCustomer method
		String id = "C100";
		String firstName = "Pradeep";
		String lastName="kumar";
		String mobile="857857";
		
		//expected output is customer object
		
		String expectedCustomerId = "C100";
		
		int expectedCount = 1; 
		
		//actual output
		
		Customer customer = manager.addCustomer(id, firstName, lastName, mobile);
		
		Collection<Customer> list = manager.getAllCustomers();
		int actualCount  = list.size();
		
		String actualCustomerId = customer.getCustomerId();
		
		//assertEquals will expect expectedoutput and actualoutput to be equals
		//if theye are not eqaul this will fail
		assertEquals(expectedCustomerId,actualCustomerId);
		
		assertEquals(expectedCount,actualCount);
		
		//this will expect the condition that is passed to be false. If
		//the condition is false, then this test will pass
		assertFalse(list.isEmpty());
		
		//the condition is true, so assertFalse will make this test fail
		//assertFalse(!list.isEmpty());
		
		//the conditiom to be true, then test case is passed
		//else failed
		assertTrue(list.isEmpty());
		
		
		assertTrue(!list.isEmpty());
		
		//assertFalse- if the condition is true, then assertFalse makes test fail
		//if the condition is false, then assertFalse makes test pass
		
		//assertTrue - if the condition is true, then assertTrue makes test pass
		//if the condition is false, then assertTrue makes test fail
		
	}
	
	@Test
	public void checkForCustomerIsNotNull() {
		
		//define the input
		String id = "C100";
		String firstName = "Pradeep";
		String lastName="kumar";
		String mobile="857857";
		
		Customer customer = manager.addCustomer(id, firstName, lastName, mobile);
		
		//the object should be not null, then assertNotNull will make test pass
		//if the object is null, then assertNotNull will make test fail
		assertNotNull(customer);
		
		//the object should be null, then assertNull will make test pass
		//otherwise this will make test fail
		assertNull(customer);
		
		
	}
	
	
	@Test
	public void shouldThrowExceptionWhenFirstNameIsNull() {
		
		//In thos example, assertThrows expects RuntimeExecption when the lambda
		//code gets executed
		//If the lambda code(expression) executes and throws RuntimeException
		//then this test is passed
		Assertions.assertThrows(RuntimeException.class, () -> {
			manager.addCustomer("101", "kiran", "kumar", "7475575");
		});
		//assertThrows is expecting the lambda code to return NullPointerException
		//but the actual exception returned from lambda code is arithmetic exception
		//this test is failed
		/*Assertions.assertThrows(NullPointerException.class, () -> {
			int a = 2/0;
		});*/
		
		//assertThrows is expecting NullPointerException but the lambda
		//code is not returning any exception
		//this test is failed
		/*Assertions.assertThrows(NullPointerException.class, () -> {
			int a = 2/1;
		});*/
		
		//assertThrows is expecting Exception from the Lambda code execution
		//the lambda code is throwing ArithemeticException
		//ArithemeticException is also an Exception class
		//this test is passed
		/*Assertions.assertThrows(Exception.class, () -> {
			int a = 2/0;
		});*/
		
	}
	
	@AfterEach
	public void close() {
		manager = null;
	}
}