package com.junitdemo1;


public class App 
{
	//business method that adds 2 numbers and 
	//return the result
    public int sum(int x, int y) {
    	return x+y;
    }
    
    public int product(int x, int y) {
    	return x*y;
    }
}
