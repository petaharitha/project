package com.junitdemo1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class AppTest {
	
	//this indicates the method is a test method
	//that is executed by Junit library
	@Test
	public void testSum() {
		
		//input to be passed
		int x = 10;
		int y = 30;
		//expected output
		int expectedOutput = 40;
		
		App app = new App();
		
		int actualOutput = app.sum(x,y);
		
		
		//assertEquals is a part of Junit library
		//assertEuquals will match expectedOutput and actualOutput
		//and if both are equal, then junit makes this test as pass
		//otherwise junit will make test as fail
		assertEquals(expectedOutput,actualOutput);
		
		
	}
	
	@Test
	public void testProduct() {
		//input passed
		int x = 20;
		int y = 5;
		
		//expected output
		int expectedOutput = 100;
		
		App app = new App();
		int actualOutput = app.product(x, y);
		
		assertEquals(expectedOutput,actualOutput);
		
	}
	
	
}