package com.mockitodemo1;

public class Calculator {
	
	/**
	 * This method takes 2 inputs, calculates sum and returns the result
	 * @param num1
	 * @param num2
	 * @return
	 */
	public int sum(int num1, int num2) {
		System.out.println("in sum method");
		return num1+num2;
	}
	
	/**
	 * This method takes 2 inputs, calculates product and returns the result
	 * @param num1
	 * @param num2
	 * @return
	 */
	public int product(int num1, int num2) {
		System.out.println("in product method");
		return num1*num2;
	}

}
