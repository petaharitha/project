package com.mockitodemo1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/**
 * Unit test for Calculator
 */
public class CalculatorTest 
{


	@Test
	public void sumTest() {

		//define input
		int num1 = 10;
		int num2 = 20;

		//define expectedoutput
		int expectedoutput = 30;

		//get the actualoutput
		//c is the real object reference
		//Calculator c = new Calculator();
		//from real object we are calling the real method
		//this is calling real method, the logic in the real method gets executed
		//int actualoutput = c.sum(num1, num2);

		//real object method sum behaviour is when we call sum method
		//from the real object reference, the sum method will take
		//2 input parameters and return the sum of the 2 input params as the
		//result

		//c is the mock object referebce
		Calculator c = Mockito.mock(Calculator.class);

		//when sum method of mock object reference is called where 
		//the method takes 2 input params, the result will be sum of
		//2 input params

		//this is the mock object sum method logic
		when(c.sum(num1, num2)).thenReturn(num1+num2);

		//this call will execute the above logic and not the real method logic
		int actualoutput = c.sum(num1,num2);

		//need to create same behaviour of real object method
		assertEquals(expectedoutput,actualoutput);
	}

	@Test
	public void productTest() {

		//define input
		int num1 = 10;
		int num2 = 20;

		//define expectedoutput
		int expectedoutput = 200;

		//c is the mock object referebce
		Calculator c = Mockito.mock(Calculator.class);

		//when product method of mock object reference is called where 
		//the method takes 2 input params, the result will be product of
		//2 input params

		//this is the mock object sum method logic
		when(c.product(num1, num2)).thenReturn(num1*num2);

		//this call will execute the above logic and not the real method logic
		int actualoutput = c.product(num1,num2);

		//need to create same behaviour of real object method
		assertEquals(expectedoutput,actualoutput);



	}
}
